package ca.techgarage.blocks;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.component.SuspiciousStewEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public class Pyrotunia extends GrowableFlowerBlock {

    public Pyrotunia(BlockBehaviour.Properties properties) {
        super(SuspiciousStewEffects.EMPTY, properties, 3, 0.25f);
    }

    @Override
    protected void onFullyGrown(Level world, BlockPos pos, BlockState state) {

    }
}