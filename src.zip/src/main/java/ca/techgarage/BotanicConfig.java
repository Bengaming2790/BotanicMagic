package ca.techgarage;


import ca.techgarage.bscm.Comment;

public class BotanicConfig {

    @Comment("Fire ticks from fire spell (each level increase adds 1 second) [In Seconds]")
    public static int fireTick = 5;

}
