package ca.techgarage.spells.effect;

import ca.techgarage.BotanicConfig;
import ca.techgarage.spells.Spell;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

public class FireEffect implements Spell {

        private final float damage;
        private final int burnTicks;

        public FireEffect(float damage) {
            this.damage = damage;
            this.burnTicks = BotanicConfig.fireTick;
        }

        @Override
        public void apply(Level level, LivingEntity caster, LivingEntity target) {
            target.hurt(level.damageSources().magic(), damage);
            target.igniteForTicks(burnTicks * 20);
        }
}
