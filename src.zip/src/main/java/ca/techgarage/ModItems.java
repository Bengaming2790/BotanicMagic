package ca.techgarage;


import ca.techgarage.items.PyrotuniaSeedsItem;
import ca.techgarage.items.Textbook;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

import java.util.function.Function;

public class ModItems {

    public static Item TEXTBOOK;
    public static Item PYROTUNIA_SEEDS;

    public static void initialize() {
        TEXTBOOK = register("textbook", Textbook::new, new Item.Properties());
        PYROTUNIA_SEEDS = register("pyrotunia_seeds", PyrotuniaSeedsItem::new, new Item.Properties());
    }

    public static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties settings) {
        Identifier id = Identifier.fromNamespaceAndPath(BotanicMagic.MOD_ID, name);

        settings = settings.setId(ResourceKey.create(Registries.ITEM, id));

        T item = factory.apply(settings);

        return Registry.register(BuiltInRegistries.ITEM, id, item);
    }
}