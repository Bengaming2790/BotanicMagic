package ca.techgarage.client;

import ca.techgarage.bscm.Comment;

public class BotanicClientConfig {
    @Comment("test client config")
    public boolean test = true;
}
