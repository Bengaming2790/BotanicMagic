package ca.techgarage.client;

import ca.techgarage.bscm.client.BSCMModMenuIntegration;

public class BotanicMagicModMenuIntegration extends BSCMModMenuIntegration {
    protected BotanicMagicModMenuIntegration(Class<?> configClass, String filename) {
        super(BotanicClientConfig.class, "botanicmagic-client");
    }
}
