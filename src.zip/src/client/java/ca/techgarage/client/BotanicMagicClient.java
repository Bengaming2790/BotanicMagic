package ca.techgarage.client;

import ca.techgarage.bscm.Bscm;
import net.fabricmc.api.ClientModInitializer;

public class BotanicMagicClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		Bscm.load(BotanicClientConfig.class, "botanicmagic-client");

	}
}